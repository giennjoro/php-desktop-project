<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Webpage extends Model
{
    public $primaryKey = 'id';
}
