<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Metatag extends Model
{
    public $primaryKey = 'id';
}
