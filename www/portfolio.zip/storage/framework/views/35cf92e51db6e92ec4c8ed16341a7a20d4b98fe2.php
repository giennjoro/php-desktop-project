<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Left side column. contains the logo and sidebar -->
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
            <h1>
               Edit Todo
                <small>Edit this Item Here</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li class="active">Edit Todo</li>
            </ol>
            </section>
            <!-- Main content -->
            <section class="content">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                    <h3 class="box-title fa fa-plus">Edit Todo Item</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php echo Form::open(['action' => ['HomeController@update', $todo->id], 'method' => 'POST','enctype' => 'multipart/form-data']); ?>

                          <div class="box-body">
                                <div class="form-group col-sm-12">
                                    <?php echo e(Form::label('Duration','',['class'=>'col-sm-2 control-label'])); ?>

    
                                    <div class="row col-sm-10">
                                    <div class="col-sm-6">
                                        <?php echo e(Form::number('duration' ,$todo->duration, ['step'=>'1','class' => 'form-control col-sm-5','placeholder' => 'Eg. 1,2,7,11'])); ?>

                                    </div>
                                    <div class="col-sm-6">
                                        <select name="measure" class="form-control">
                                            <option value = '<?php echo e($todo->measure); ?>' ><?php echo e($todo->measure); ?></option>
                                            <option value = 'day(s)' >Day</option>
                                            <option value = 'week(s)' >week</option>
                                            <option value = 'hour(s)' >Hour</option>
                                        </select>
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group col-sm-12">
                                    <?php echo e(Form::label('Description','',['class'=>'col-sm-2 control-label'])); ?>

    
                                    <div class="row col-sm-10">
                                        <div class="col-sm-12">
                                            <?php echo e(Form::text('description' ,$todo->description,['class' => 'form-control','placeholder' => 'Eg. Create a Project'])); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php echo e(Form::hidden('_method','PUT')); ?>

                          <div class="box-footer">
                              <?php echo e(Form::button('Edit item',['class'=>'btn btn-success fa fa-pencil pull-right','type'=>'submit'])); ?>

                          </div>
                      <?php echo Form::close(); ?>

                </div>
             
                
                <!-- /.box -->
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>
<!-- ./wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>