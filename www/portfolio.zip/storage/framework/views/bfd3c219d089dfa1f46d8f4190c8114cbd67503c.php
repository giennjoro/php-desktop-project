<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Left side column. contains the logo and sidebar -->
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
            <h1>
               <?php echo e($user->name); ?>

                <small>Fields with asterik(<span style = "color: red">*</span>) are mandatory</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="#">Admins</a></li>
                <li class="active">New Admin</li>
            </ol>
            </section>
            <!-- Main content -->
            <section class="content">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                    <h3 class="box-title fa fa-pencil">Edit <?php echo e($user->name); ?></h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                   <?php echo Form::open(['action' => ['UsersController@update', $user->slug], 'method' => 'PUT', 'enctype' => 'multipart/form-data']); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('name', 'Enter Name')); ?> <span style = "color: red">*</span>
                            <?php echo e(Form::text('name', $user->name, ['class' => 'form-control', 'id' => 'name'])); ?> <br>
                            
                            <?php echo e(Form::label('email', 'Enter Email')); ?> <span style = "color: red">*</span>
                            <?php echo e(Form::text('email', $user->email, ['class' => 'form-control', 'id' => 'email'])); ?> <br>
                            
                            <?php echo e(Form::label('password', 'Type Password ONLY IF You Need To Change!')); ?>

                            <?php echo e(Form::text('password','', ['class' => 'form-control', 'id' => 'password', 'placeholder' => 'Type the new password here'])); ?> <br>
                            
                            <?php echo e(Form::label('confirm_password', 'Confirm Password ONLY IF You Need To Change!')); ?>

                            <?php echo e(Form::text('confirm_password','', ['class' => 'form-control', 'id' => 'confirm_password', 'placeholder' => 'Confirm password'])); ?> <br>
                            
                            <?php echo e(Form::label('phone', 'Enter Phone Number')); ?> 
                            <?php echo e(Form::text('phone', $user->phone, ['class' => 'form-control', 'id' => 'phone',])); ?> <br>
                            
                            <div class="<?php if(!Auth::user()->supper): ?> hidden <?php endif; ?>">
                                <input type="checkbox" name="supper" <?php if($user->supper): ?> checked <?php endif; ?> }}>
                                <?php echo e(Form::label('supper', 'Make Supper Admin')); ?> <br> <br>
                            </div>
                            

                            <?php echo e(Form::label('avatar', 'Upload an avatar')); ?>

                            <?php echo e(Form::file('avatar', ['class' => 'form-control'])); ?> <br>
                            <!--  -->
                        </div>
                      <div class="box-footer">
                        <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                      </div>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.box -->
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>
<!-- ./wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>