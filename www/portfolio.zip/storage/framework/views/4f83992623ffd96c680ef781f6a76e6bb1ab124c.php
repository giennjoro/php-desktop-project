<?php $__env->startSection('content'); ?>
<body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
        <a href="/"> <img src="<?php echo e(asset('/img/logo.png')); ?>" alt=""> </a>
      </div>
      <!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Sign in to start your session</p>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group has-feedback">
                        <input type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required >
                        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>

                        <?php if($errors->has('email')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                            <?php echo e($errors->first('email')); ?>

                            </div>

                        <?php endif; ?>
                    
                </div>

                <div class="form-group has-feedback">
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>

                        <?php if($errors->has('password')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                            <?php echo e($errors->first('password')); ?>

                            </div>
                        <?php endif; ?>
                    
                </div>
                
                <div class="row">
                    <div class="col-xs-12">
                        <div>
                        <label>
                            <input type="checkbox" class="form-check-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>  Remember me
                        </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat"><?php echo e(__('Login')); ?></button>
                    </div>
                    <!-- /.col -->
                </div>

            </form>
            <a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Your Password?')); ?></a><br>
      </div>
                <!-- /.login-box-body -->
             
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>