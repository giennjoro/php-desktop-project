<?php $__env->startSection('content'); ?>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            subscribers
            <small>Available subscribers</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="/admin/subscribers/create"><i class="fa fa-plus"></i>Add Subscriber</a></li>
            <li class="active">subscribers</li>
          </ol>
        </section>
    
        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Available subscribers</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php if(count($subscribers) > 0): ?>
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                            <th>Subscriber's Email</th>
                            <th>Subscriber since</th>
                            <th>Edit Subscriber</th>
                            <th>Remove Subscriber</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($subscriber->email); ?></td>
                                        <td><?php echo e(date('F d, Y', strtotime($subscriber->created_at))); ?></td>
                                        <td>
                                            <a href='/admin/subscribers/<?php echo e($subscriber->id); ?>/edit' ><button class="btn btn-success fa fa-pencil"> Edit</button></a>
                                        </td>
                                        <td>
                                            <?php echo Form::open(['action' => ['SubscribersController@destroy',$subscriber->id], 'method' => 'POST', 'onsubmit' => 'return ConfirmDelete()']); ?>

                                                <?php echo e(Form::hidden('_method' ,'DELETE')); ?>

                                                
                                                <?php echo e(Form::submit('Remove',['class'=>'btn btn-danger'])); ?>

                                            
                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>Subscriber's Email</th>
                                <th>Subscriber since</th>
                                <th>Edit Subscriber</th>
                                <th>Remove Subscriber</th>
                            </tr>
                            </tfoot>
                        </table>
                    <?php else: ?>
                        <p>There are no subscribers to display</p>
                    <?php endif; ?>
                </div>
                <!-- /.box-body -->
              </div>
              <!-- /.box -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>