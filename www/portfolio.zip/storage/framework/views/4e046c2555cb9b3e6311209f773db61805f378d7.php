<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Left side column. contains the logo and sidebar -->
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
            <h1>
              Edit Partners
                <small>Edit this Partner</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="/admin/partners">Partners</a></li>
                <li class="active">Edit Partner</li>
            </ol>
            </section>
            <!-- Main content -->
            <section class="content">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                    <h3 class="box-title fa fa-plus">Edit Partner</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php echo Form::open(['action' => ['PartnersController@update',$partner->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                        <div class="box-body">
                            <div class="form-group">
                                <?php echo e(Form::label('Website URL')); ?>


                                <?php echo e(Form::text('url' ,$partner->link, ['class' => 'form-control','id' => 'exampleInputEmail1', 'placeholder' => 'Enter Website URL Here'])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('title')); ?>


                                <?php echo e(Form::file('logo')); ?>

                            </div>
                                <?php echo e(Form::hidden('_method','PUT')); ?>

                        </div>
                        <div class="box-footer">
                            <?php echo e(Form::submit('Update Partner',['class'=>'btn btn-primary'])); ?>

                        </div>
                    <?php echo Form::close(); ?>

                </div>
             
                
                <!-- /.box -->
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>
<!-- ./wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>