<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Left side column. contains the logo and sidebar -->
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
            <h1>
               Edit <?php echo e($client->name); ?>

                <small>Fields with an asterik(<span style = "color: red">*</span>) are mandatory</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                <li><a href="<?php echo e(route('clients.index')); ?>">Projects</a></li>
                <li class="active">Edit Project</li>
            </ol>
            </section>
            <!-- Main content -->
            <section class="content">
            <div class="row">
                <!-- left column -->
                <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                    <h3 class="box-title fa fa-pencil">Edit Project</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <?php echo Form::open(['action' => ['ClientsController@update', 'slug' => $client->slug], 'method' => 'PUT', 'enctype' => 'multipart/form-data']); ?>

                        <div class="form-group">
                            <?php echo e(Form::label('name', 'Name of the Client\'s site')); ?> <span style = "color: red">*</span>
                            <?php echo e(Form::text('name', $client->name, ['class' => 'form-control', 'id' => 'name', 'placeholder' => 'Enter Name of the Client Here'])); ?> <br>
                            
                            <?php echo e(Form::label('url', 'Url of the site')); ?> <span style = "color: red">*</span>
                            <?php echo e(Form::text('url', $client->url, ['class' => 'form-control', 'id' => 'url', 'placeholder' => 'Enter Url of the Site Here'])); ?> <br>
                            
                            <?php echo e(Form::label('phone', 'Phone Number of the Client')); ?>

                            <?php echo e(Form::text('phone', $client->phone, ['class' => 'form-control', 'id' => 'phone', 'placeholder' => 'Enter Phone Number of the Client Here'])); ?> <br>
                            
                            <?php echo e(Form::label('source_code_link', 'Source Code Link')); ?>

                            <?php echo e(Form::text('source_code_link', $client->source_code_link, ['class' => 'form-control', 'id' => 'source_code_link', 'placeholder' => 'Enter the Source Code Link Here'])); ?> <br>

                            <?php echo e(Form::label('cpanel_username', 'CPanel Username')); ?>

                            <?php echo e(Form::text('cpanel_username', $client->cpanel_username, ['class' => 'form-control', 'id' => 'cpanel_username', 'placeholder' => 'Enter the CPanel Username Here'])); ?> <br>
                            
                            <?php echo e(Form::label('cpanel_password', 'CPanel Password')); ?>

                            <?php echo e(Form::text('cpanel_password', $client->cpanel_password, ['class' => 'form-control', 'id' => 'cpanel_password', 'placeholder' => 'Enter the CPanel Password Here'])); ?> <br>

                            <?php echo e(Form::label('admin_username', 'Admin Username')); ?>

                            <?php echo e(Form::text('admin_username', $client->admin_username, ['class' => 'form-control', 'id' => 'admin_username', 'placeholder' => 'Enter Admin Username Here'])); ?> <br>
                            
                            <?php echo e(Form::label('admin_password', 'Admin Password')); ?>

                            <?php echo e(Form::text('admin_password', $client->admin_password, ['class' => 'form-control', 'id' => 'admin_password', 'placeholder' => 'Enter Admin Password Here'])); ?> <br>

                            <?php echo e(Form::label('image', 'Upload an Image')); ?> <span style = "color: red">*</span>
                            <?php echo e(Form::FIle('image')); ?> <br>
                        </div>
                      <div class="box-footer">
                        <?php echo e(Form::submit('Add Client', ['class' => 'btn btn-primary'])); ?>

                      </div>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.box -->
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>
<!-- ./wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>