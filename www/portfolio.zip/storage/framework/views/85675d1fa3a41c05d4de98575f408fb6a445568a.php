<?php $__env->startSection('content'); ?>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           View Slider
            <small>Preview of the Slider</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('sliders.create')); ?>"> Add Slider Item</a></li>
            <li class="active">Slider</li>
          </ol>
        </section>
    
        <!-- Main content -->
        <section class="content">
          <!-- START CAROUSEL-->
          <h2 class="page-header">Slider Items</h2>
          <div class="col-md-12">
            <div class="box box-solid">
              <div class="box-header with-border">
                <h3 class="box-title">Slider</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body">
                <?php if($sliders->count() == 0): ?>
                  <p>No Slider to Display</p>
                <?php else: ?>
                  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                      <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                      <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                      <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                    </ol>
                    <div class="carousel-inner">
                      <div class="hidden"><?php echo e($n = 1); ?></div>
                      
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="item <?php if($n == 1): ?> active <?php endif; ?>">
                            <img src="<?php echo e(asset($slider->image)); ?>" alt="Slide">
        
                            <div class="col-md-12">
                            

                              
                            </div>
                            <div class="row">
                              <div class="col-md-12" style="text-align:center;">
                                <div class="box">
                                  <div class="box-header with-border">
                                  <h3> <strong><?php echo e($slider->message); ?></strong> </h3>
                                  </div>
                                  <!-- /.box-header -->
                                  <div class="box-body col-md-12">
                                  <table  class="table">
                                        <thead>
                                            <tr>
                                                <td><a href="#"><button class=" btn btn-success fa fa-eye" data-toggle="tooltip" title="<?php echo e($slider->link); ?>"><?php echo e($slider->link_message); ?></button></a> </td>
                                                <td><?php echo Form::open(['action' => ['SlidersController@destroy', $slider->slug], 'method' => 'POST', 'id' => 'delete_form', 'onsubmit' => 'return ConfirmDelete()']); ?>

                                                    <?php echo e(Form::hidden('_method','DELETE')); ?>

                                            
                                                    <?php echo e(Form::button(' Delete',['class'=>'btn btn-danger fa fa-trash', 'type' => 'submit'])); ?>

                                        
                                                    <?php echo Form::close(); ?>

                                                </td>
                                                
                                                <td>
                                                  <a href="<?php echo e(route('sliders.edit', ['slug' => $slider->slug])); ?>" class="btn btn-primary ">
                                                    <i class="fa fa-pencil"></i> Edit
                                                  </a>
                                                </td> 
                                            </tr>   
                                        </thead>
                                        
                                    </table>
                                    
                                    
                                    <h4><?php echo e($slider->title); ?></h4>
                                  </div>

                                  <div style="height:5px;">

                                  </div>
                                  <!-- /.box-body -->
                                </div>
                                <!-- /.box -->
                              </div>
                            </div>
                          </div>
                          <div class="hidden"><?php echo e($n = $n + 1); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                      
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                      <span class="fa fa-angle-left"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                      <span class="fa fa-angle-right"></span>
                    </a>
                  </div>
                <?php endif; ?>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
          <!-- END  CAROUSEL-->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>