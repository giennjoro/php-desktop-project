<?php $__env->startSection('metatags'); ?>
    <?php $__currentLoopData = $metatags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metatag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <meta name="<?php echo e($metatag->name); ?>" content="<?php echo e($metatag->content); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title-wrap" data-bg-img="img/hills.jpg" data-rjs="2">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="page-title" data-animate="fadeInUp" data-delay="1.2">
                        <h2>Our Portfolio</h2>
                        <ul class="list-unstyled m-0 d-flex">
                            <li><a href="index.html"><i class="fa fa-home"></i> Home</a></li>
                            <li><a href="portfolio.html">Our Portfolio</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Page Title -->
    
    <section class="pt-120 pb-65">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="blog">
                        <div class="row isotope">
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6">
                                    <div class="single-news mb-55" data-animate="fadeInUp" data-delay=".1">
                                        <a class="tip" target="_blank" href="<?php echo e($project->url); ?>">Jump to site</a>
                                        <img src="<?php echo e(asset($project->image)); ?>" data-rjs="2" alt="P.C.E.A Kangoya Child Development Center">
                                        <h3 align="center" class="h5"><a href="<?php echo e($project->url); ?>" target="_blank"><?php echo e($project->name); ?></a></h3>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>