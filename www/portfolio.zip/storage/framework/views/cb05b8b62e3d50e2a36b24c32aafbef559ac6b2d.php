<?php $__env->startSection('content'); ?>
    <!-- Services -->
    <section class="pt-120 pb-90">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single-service text-center" data-animate="fadeInUp" data-delay=".1">
                        <img src="img/icons/web-design.svg" alt="Web Design" class="svg">
                        <h4>Web Design</h4>
                        <p>Get your web design services from the best web designer in Kenya. <strong>24seven developers</strong> designs and develops websites for corporates, hotel management system... </p>
                        <a href="web-design.html">Learn More <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-service text-center" data-animate="fadeInUp" data-delay=".4">
                        <img src="img/icons/ux.svg" alt="Graphics Design" class="svg">
                        <h4>Graphics Design</h4>
                        <p>Good UI/UX helps people to understand and identify with your brand better. You get a free logo when we design a website for you. We help in branding your business better by designing your posters, bronchures...</p>
                        <a href="graphics-design.html">Learn More <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-service text-center" data-animate="fadeInUp" data-delay=".7">
                        <img src="img/icons/digital-campaign.svg" alt="Digital Marketing" class="svg">
                        <h4>Digital Marketing</h4>
                        <p>It is worth noting that the number of people online is still increasing. We make your business more visible online through Search Engine Optimization(SEO), Content marketing...</p>
                        <a href="digital-marketing.html">Learn More <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="single-service text-center" data-animate="fadeInUp" data-delay="1">
                        <img src="img/icons/hosting.svg" alt="Web Hosting" class="svg">
                        <h4>Web Hosting</h4>
                        <p>With more business online, you should host your website with the best servers to outdo the rest. Get the fastest web hosting services in Kenya.</p>
                        <a href="https://tbxhost.co.uk/" target="_blank">Visit site <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Services -->
    
    
    <!-- Subscription -->
    <section class="pt-120 pb-120">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-5">
                    <div class="section-title pb-0" data-animate="fadeInUp" data-delay=".1">
                        <h2>Subscribe to Newsletter</h2>
                        <p class="mb-0">Let us update you with 24seven tech bytes</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-7">
                    <!-- Subscription form -->
                    <div class="subscription-form" data-animate="fadeInUp" data-delay=".4">
                        <form  action="subscribe.php" method="post" name="mc-embedded-subscribe-form">
                            <input type="email" name="email" class="theme-input-style" placeholder="Enter your e-mail address" required>
                            <button class="btn" name="submit" type="submit">Subscribe Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Subscription -->

    <!-- Brands -->
    <section class="light-bg pt-80 pb-50">
        <div class="container">
            <div class="row">
                <div class="col">
                    <ul class="brands list-unstyled d-flex flex-wrap align-items-center justify-content-center justify-content-md-between mb-0">
                        <li data-animate="fadeInUp" data-delay=".05"><img src="img/brands/brand1.png" alt=""></li>
                        <li data-animate="fadeInUp" data-delay=".2"><img src="img/brands/brand2.png" alt=""></li>
                        <li data-animate="fadeInUp" data-delay=".35"><img src="img/brands/brand3.png" alt=""></li>
                        <li data-animate="fadeInUp" data-delay=".5"><img src="img/brands/brand4.png" alt=""></li>
                        <li data-animate="fadeInUp" data-delay=".65"><img src="img/brands/brand5.png" alt=""></li>
                        <li data-animate="fadeInUp" data-delay=".8"><img src="img/brands/brand6.png" alt=""></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- End of Brands -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>