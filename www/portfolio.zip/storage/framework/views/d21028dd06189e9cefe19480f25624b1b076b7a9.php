<?php $__env->startSection('content'); ?>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Left side column. contains the logo and sidebar -->
        <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Content Wrapper. Contains page content -->
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                  <h1>
                    <?php echo e($user->name); ?>'s Profile
                  </h1>
                  <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-dashboard"></i> Users</a></li>
                    <li><a href="<?php echo e(route('users.index')); ?>">Admins</a></li>
                    <li class="active">User profile</li>
                  </ol>
                </section>
            
                <!-- Main content -->
                <section class="content">
            
                  <div class="row">
                    <div class="col-md-6">
                      <!-- Profile Image -->
                        <div class="box box-primary" style="height:410px;">
                            <div class="box-body box-profile">
                            <a href="<?php echo e(asset($user->avatar)); ?>">
                              <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset($user->avatar)); ?>" alt="User profile picture">
                            </a>
            
                            <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
                            <ul class="list-group list-group-unbordered">
                              <li class="list-group-item">
                                  <b>Member Since</b> <a class="pull-right"><?php echo e(date('F d, Y', strtotime($user->created_at))); ?></a>
                              </li>
                              <li class="list-group-item">
                                  <b>Email</b> <a class="pull-right"><?php echo e($user->email); ?></a>
                              </li>
                              <li class="list-group-item">
                                  <b>Phone</b> <a class="pull-right"><?php echo e($user->phone); ?></a>
                              </li>
                              <li class="list-group-item <?php if(!$user->supper): ?> hidden <?php endif; ?>">
                                  <b>Admin Status</b> <a class="pull-right">Supper Admin</a>
                              </li>
                              <li class="list-group-item <?php if($user->supper): ?> hidden <?php endif; ?>">
                                  <b>Admin Status</b> <a class="pull-right">Ordinary Admin</a>
                              </li>
                            </ul>
                                <?php echo Form::open(['action' => ['UsersController@destroy', $user->slug], 'method' => 'DELETE']); ?>

                                        <?php if(Auth::user() == $user): ?>
                                            <button onClick= "javascript: return confirm ('Are you sure you want to exit?');" class="btn btn-danger" type="submit">Exit</button>
                                        <?php else: ?>
                                        <button onClick= "javascript: return confirm ('Are you sure you want to remove <?php echo e($user->name); ?>?');" class="btn btn-danger" type="submit">Remove</button>
                                        <?php endif; ?>
                                <?php echo Form::close(); ?>

                            </div>
                        <!-- /.box-body -->
                        </div>
                      <!-- /.box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-6">
                      <!--edit profile details-->
                      <div class="box box-primary"   style="height:410px;">
                        <div class="box-header with-border">
                          <h3 class="box-title">Edit User Details</h3>
                        </div>
                        <!-- /.box-header -->
                        <!-- form start -->
                        
                        <form role="form">
                          <div class="box-body">
                            <div class="form-group">
                              <label for="exampleInputPassword1"> Admin Name </label>
                              <input value="<?php echo e($user->name); ?>" type="text" name = "name" class="form-control" id="exampleInputPassword1" placeholder="Name">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputEmail1"> Email address</label>
                              <input value="<?php echo e($user->email); ?>" type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputPassword1">Phone</label>
                              <input value="<?php echo e($user->phone); ?>" type="text" class="form-control" id="exampleInputPassword1" placeholder="Phone">
                            </div>
                            <div class="form-group">
                              <label for="exampleInputFile">Change Display Image</label>
                              <input type="file" name="profile" id="exampleInputFile">
            
                            <!--<p class="help-block">Example block-level help text here.</p>-->
                            </div>
                          </div>
                          <!-- /.box-body -->
            
                          <div class="box-footer">
                            <!-- <button type="submit" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button> -->
                            <a href="<?php echo e(route('users.edit', ['slug' => $user->slug])); ?>" class="btn btn-primary"><i class="fa fa-eye"></i>show all</a>
                          </div>
                        </form>
                      </div>
                      <!--end edit profile details-->
                    </div>
                    <!-- /.col -->
                  </div>
                  <!-- /.row -->
            
                </section>
                <!-- /.content -->
            </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.aside_right', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</body>
<!-- ./wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>