You received a message from : {{ $email }}
 
<p>
Name: {{ $name }}
</p>
 
<p>
Email: {{ $email }}
</p>

<p>
    Phone: {{$phone}}
</p>
<p>
 Subject: {{$subject}}   
</p>
 
<p>
Message: {{ $user_message }}
</p>