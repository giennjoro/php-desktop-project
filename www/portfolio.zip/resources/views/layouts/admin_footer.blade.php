<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>24 seven</b> Developers
    </div>
    <strong>Copyright &copy; 2018 <a href="#"> 24 Seven Developers</a>.</strong> All rights
    reserved.
</footer>